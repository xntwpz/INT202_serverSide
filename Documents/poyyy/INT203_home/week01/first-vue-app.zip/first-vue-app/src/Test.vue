<script setup>
    // crete  by type sfc

</script>
 
<template>
<div>

</div>
</template>
 
<style scoped>

</style>